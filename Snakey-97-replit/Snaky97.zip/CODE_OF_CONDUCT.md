# Battlesnake Code of Conduct

Please see https://docs.battlesnake.com/policies/conduct
